package JavaConfig;

import com.People;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan("com")
@Import(JavaConfig2.class)
public class JavaConfig {
    @Bean("people")
    public People getPeople(){
        return new People();
    }
}
