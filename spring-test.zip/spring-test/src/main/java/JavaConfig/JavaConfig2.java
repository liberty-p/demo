package JavaConfig;

import com.People;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig2 {
    @Bean("people2")
    public People getPeople(){
        return new People();
    }
}
