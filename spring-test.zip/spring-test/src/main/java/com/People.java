package com;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;


public class People {
    @Value("panzhenyu")
    String name;
    @Value("23")
    int age;
    String[] str;
    List<Integer> list;



    public void setStr(String[] str){
        this.str = str;
    }
    public void setList(List<Integer> list){
        this.list = list;
    }

    public People(String name,int age){
        this.name = name;
        this.age = age;
    }
    public People(){

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void print(){
        System.out.println(name+","+age);
    }
}
