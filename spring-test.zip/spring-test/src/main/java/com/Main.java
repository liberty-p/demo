package com;

import JavaConfig.JavaConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

public class Main {
    public static void main(String[] args) {
       //ApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
        AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(JavaConfig.class);
        Test test = ac.getBean("test", Test.class);
        test.pri();

    }
}

@Component
class Test{
    @Autowired
    People people2;
    public void pri(){
        people2.print();
    }
}